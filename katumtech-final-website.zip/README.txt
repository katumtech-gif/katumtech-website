
Katumtech Engineers - Final website package ready for deployment
Files included:
- index.html, about.html, services.html, contact.html
- css/styles.css
- assets/logo.png (or logo.svg), assets/tech-hero.svg, assets/favicon.svg
Instructions:
1. Upload to your GitHub repo (commit files) or drag into Vercel (if available).
2. Vercel will auto-deploy; ensure your domain nameservers point to Vercel.
3. Contact me if you need assistance.
